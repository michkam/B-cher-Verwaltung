  function zeige(inhalt1){
		  var inhalte1=new Array("home","Neu","Impressum","Shop","Ankauf","AGB");
		  document.getElementById("start").innerHTML=""; 
		  for(var i=0; i<inhalte1.length; i++)
			  document.getElementById(inhalte1[i]).style.display='none';
		      document.getElementById(inhalt1).style.display='block';
	       }	  
/*function home(){
    window.location.href= "file:///Users/admin/Desktop/Web/mySite/HTML/Josif/home.html";
} */