<!DOCTYPE html>
<html>
  <head>
    <title>Kontakt</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="stylesheet" type="text/css" href="kontakt.css"> 
	<link rel="stylesheet" type="text/css" href="index.css"> 
  </head>
    <body>
<div id="part0">
	<?php 
$vorname=$HTTP_POST_VARS['Vorname']; 
$nachname=$HTTP_POST_VARS['Nachname']; 
$b_titel=$HTTP_POST_VARS['Titel des Buchs']; 
$m_adresse=$HTTP_POST_VARS['Email-adresse']; 
$tel=$HTTP_POST_VARS['Telefon']; 
$nachricht=$HTTP_POST_VARS['Nachricht']; 


$headers = "MIME-Version: 1.0\r\n";  
$headers .= "Content-type: text/plain; charset=iso-8859-1\r\n"; 

$headers .= "From: $nachname <$mail>\r\nReply-to : $name <$mail>\nX-Mailer:PHP"; 

$subjekt="$ankauf"
$emfaenger="dnilson0302@yahoo.com"; 
$body="$nachricht"; 
if (mail($emfaenger,$subjekt,$body,$headers)) { 
echo "Nachricht erfolreich gesendet<br>"; 
} else { 
echo "Ihre Nachricht wurde nicht gesendet<br>"; 
} 
?></p>
<p align="center">Sie werden weitergeleiten zur Shop...<br>
Wenn nicht, bitte hier kliken <a href="home.html">ici 
</a></p><br><br>	
</div>

		
		
      <a href="http://validator.w3.org/check/referer"><img
          src="http://www.w3.org/Icons/valid-html401"
          alt="Valid HTML 4.01 Transitional" height="31" width="88"></a>
    </p>
  </body>
</html>